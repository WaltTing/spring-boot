package com.boot.security.server.service.impl;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.boot.security.server.dao.UserDao;
import com.boot.security.server.dto.UserDto;
import com.boot.security.server.model.Role;
import com.boot.security.server.model.SysUser;
import com.boot.security.server.model.SysUser.Status;
import com.boot.security.server.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	private UserDao userDao;
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@Override
	@Transactional
	public SysUser saveUser(UserDto userDto) {
		SysUser user = new SysUser();
		BeanUtils.copyProperties(userDto, user);

		user.setPassword(passwordEncoder.encode(user.getPassword()));
		user.setStatus(Status.VALID);

		setRoles(userDto, user);

		userDao.save(user);

		log.debug("新增用户{}", user.getUsername());
		return user;
	}

	private void setRoles(UserDto userDto, SysUser user) {
		if (userDto.getRoleIds() != null) {
			Set<Role> roles = new HashSet<>();
			userDto.getRoleIds().forEach(roleId -> {
				Role role = new Role();
				role.setId(roleId);
				roles.add(role);
			});
			user.setRoles(roles);
		}
	}

	@Override
	public SysUser getUser(String username) {
		return userDao.findByUsername(username);
	}

	@Override
	public void changePassword(String username, String oldPassword, String newPassword) {
		SysUser u = userDao.findByUsername(username);
		if (u == null) {
			throw new IllegalArgumentException("用户不存在");
		}

		if (!passwordEncoder.matches(oldPassword, u.getPassword())) {
			throw new IllegalArgumentException("旧密码错误");
		}

		u.setPassword(passwordEncoder.encode(newPassword));
		u.setUpdateTime(new Date());
		userDao.save(u);
		log.debug("修改{}的密码", username);
	}

	@Override
	@Transactional
	public SysUser updateUser(UserDto userDto) {
		SysUser user = userDao.findById(userDto.getId()).orElse(null);

		if (userDto.getBirthday() != null) {
			user.setBirthday(userDto.getBirthday());
		}

		if (userDto.getEmail() != null) {
			user.setEmail(userDto.getEmail());
		}

		if (userDto.getHeadImgUrl() != null) {
			user.setHeadImgUrl(userDto.getHeadImgUrl());
		}

		if (userDto.getNickname() != null) {
			user.setNickname(userDto.getNickname());
		}

		if (userDto.getPhone() != null) {
			user.setPhone(userDto.getPhone());
		}

		if (userDto.getSex() != null) {
			user.setSex(userDto.getSex());
		}

		if (userDto.getStatus() != null) {
			user.setStatus(userDto.getStatus());
		}

		if (userDto.getTelephone() != null) {
			user.setTelephone(userDto.getTelephone());
		}

		setRoles(userDto, user);

		user.setUpdateTime(new Date());
		userDao.save(user);

		return userDto;
	}

}
