package com.boot.security.server.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.boot.security.server.model.Permission;

public interface PermissionDao extends JpaRepository<Permission, Long> {

	@Query("select p from Permission p where p.type = 1 order by p.sort")
	List<Permission> listParents();

	@Query("select distinct p from Permission p inner join p.roles r inner join r.users u where u.id = :userId")
	List<Permission> listByUserId(@Param("userId") Long userId);

	@Query("select p from Permission p inner join p.roles r where r.id = :roleId ")
	List<Permission> listByRoleId(@Param("roleId") Long roleId);

	@Modifying
	@Transactional
	@Query("delete from Permission where parentId = :id")
	int deleteByParentId(@Param("id") Long id);
}
