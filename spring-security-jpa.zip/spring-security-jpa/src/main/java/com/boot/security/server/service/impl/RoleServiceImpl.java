package com.boot.security.server.service.impl;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.boot.security.server.dao.RoleDao;
import com.boot.security.server.dto.RoleDto;
import com.boot.security.server.model.Permission;
import com.boot.security.server.model.Role;
import com.boot.security.server.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {

	private static final Logger log = LoggerFactory.getLogger(RoleServiceImpl.class);

	@Autowired
	private RoleDao roleDao;

	@Override
	@Transactional
	public void saveRole(RoleDto roleDto) {
		Role role = new Role();
		BeanUtils.copyProperties(roleDto, role);
		List<Long> permissionIds = roleDto.getPermissionIds();

		if (role.getId() != null) {// 修改
			updateRole(role, permissionIds);
		} else {// 新增
			saveRole(role, permissionIds);
		}
	}

	private void saveRole(Role role, List<Long> permissionIds) {
		Role r = roleDao.findByName(role.getName());
		if (r != null) {
			throw new IllegalArgumentException(role.getName() + "已存在");
		}

		setPermission(role, permissionIds);
		roleDao.save(role);
		log.debug("新增角色{}", role.getName());
	}

	private void setPermission(Role role, List<Long> permissionIds) {
		if (!CollectionUtils.isEmpty(permissionIds)) {
			permissionIds.remove(0L);
			Set<Permission> permissions = new HashSet<>();
			permissionIds.stream().forEach(permissionId -> {
				Permission permission = new Permission();
				permission.setId(permissionId);

				permissions.add(permission);
			});
			role.setPermissions(permissions);
		} else {
			role.setPermissions(null);
		}
	}

	private void updateRole(Role role, List<Long> permissionIds) {
		Role r = roleDao.findByName(role.getName());
		if (r != null && r.getId() != role.getId()) {
			throw new IllegalArgumentException(role.getName() + "已存在");
		}

		r = roleDao.findById(role.getId()).orElse(null);
		r.setName(role.getName());
		r.setDescription(role.getDescription());
		r.setUpdateTime(new Date());

		setPermission(r, permissionIds);
		roleDao.save(r);
		log.debug("修改角色{}", role.getName());
	}

	@Override
	@Transactional
	public void deleteRole(Long id) {
		roleDao.deleteById(id);

		log.debug("删除角色id:{}", id);
	}

}
