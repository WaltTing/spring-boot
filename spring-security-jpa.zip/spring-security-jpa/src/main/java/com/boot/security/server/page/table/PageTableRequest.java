package com.boot.security.server.page.table;

import java.io.Serializable;
import java.util.Map;

import org.springframework.data.domain.Sort;

/**
 * 分页查询参数
 * 
 * @author 小威老师
 *
 */
public class PageTableRequest implements Serializable {

	private static final long serialVersionUID = 7328071045193618467L;

	/**
	 * 第几页，从0开始
	 */
	private Integer page;
	/**
	 * 每页多少条数据
	 */
	private Integer pageSize;
	private Map<String, Object> params;
	private Sort sort;

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Map<String, Object> getParams() {
		return params;
	}

	public void setParams(Map<String, Object> params) {
		this.params = params;
	}

	public Sort getSort() {
		return sort;
	}

	public void setSort(Sort sort) {
		this.sort = sort;
	}

}
