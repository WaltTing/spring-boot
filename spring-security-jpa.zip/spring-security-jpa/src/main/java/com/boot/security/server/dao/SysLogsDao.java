package com.boot.security.server.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.boot.security.server.model.SysLogs;

public interface SysLogsDao extends JpaRepository<SysLogs, Long>, JpaSpecificationExecutor<SysLogs> {

}
