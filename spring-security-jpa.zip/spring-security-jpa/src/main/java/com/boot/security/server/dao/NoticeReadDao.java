package com.boot.security.server.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.boot.security.server.model.NoticeRead;
import com.boot.security.server.model.NoticeReadId;
import com.boot.security.server.model.SysUser;

public interface NoticeReadDao extends JpaRepository<NoticeRead, NoticeReadId> {

	/**
	 * 已读公告人列表
	 * 
	 * @param noticeId
	 * @return
	 */
	@Query("select u from NoticeRead r, SysUser u where u.id = r.noticeReadId.userId and r.noticeReadId.noticeId = :noticeId order by r.createTime")
	List<SysUser> listReadUsers(@Param("noticeId") Long noticeId);

	/**
	 * 未读公告数
	 * 
	 * @param userId
	 * @return
	 */
	@Query("select count(1) from Notice n where n.status = 1 and not exists(select 1 from NoticeRead r where r.noticeReadId.noticeId = n.id and r.noticeReadId.userId = :userId)")
	int countUnread(@Param("userId") Long userId);
}
