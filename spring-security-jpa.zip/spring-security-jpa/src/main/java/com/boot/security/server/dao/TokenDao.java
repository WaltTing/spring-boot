package com.boot.security.server.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.security.server.model.TokenModel;

public interface TokenDao extends JpaRepository<TokenModel, String> {

}
