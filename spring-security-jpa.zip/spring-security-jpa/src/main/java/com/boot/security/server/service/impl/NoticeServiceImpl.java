package com.boot.security.server.service.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.boot.security.server.model.Notice;
import com.boot.security.server.model.NoticeRead;
import com.boot.security.server.page.table.PageTableRequest;
import com.boot.security.server.page.table.PageTableResponse;
import com.boot.security.server.service.NoticeService;

@Service
public class NoticeServiceImpl implements NoticeService {

	@Autowired
	private EntityManager entityManager;

	@Transactional
	@Override
	public PageTableResponse queryPubNotice(PageTableRequest request, Long userId) throws ParseException {
		Map<String, Object> params = request.getParams();

		String title = MapUtils.getString(params, "title");
		String beginTime = MapUtils.getString(params, "beginTime");
		String endTime = MapUtils.getString(params, "endTime");
		Integer isRead = MapUtils.getInteger(request.getParams(), "isRead");

		Map<String, Object> queryParam = new HashMap<>();
		StringBuilder builder = new StringBuilder("from Notice n where n.status = 1 ");
		if (StringUtils.isNoneBlank(title)) {
			builder.append("and n.title like :title ");
			queryParam.put("title", "%" + title + "%");
		}
		if (StringUtils.isNoneBlank(beginTime)) {
			builder.append("and n.updateTime >= :beginTime ");
			queryParam.put("beginTime", DateUtils.parseDate(beginTime, "yyyy-MM-dd"));
		}
		if (StringUtils.isNoneBlank(endTime)) {
			builder.append("and n.updateTime <= :endTime ");
			queryParam.put("endTime", DateUtils.parseDate(endTime + " 23:59:59", "yyyy-MM-dd HH:mm:ss"));
		}
		if (isRead != null) {
			if (isRead == 1) {// 已读
				builder.append("and exists  ");
			} else {// 未读
				builder.append("and not exists ");
			}

			builder.append(
					"(select 1 from NoticeRead r where r.noticeReadId.userId = :userId and r.noticeReadId.noticeId = n.id) ");
			queryParam.put("userId", userId);
		}

		TypedQuery<Long> countQuery = entityManager.createQuery("select count(n) " + builder, Long.class);
		setParam(countQuery, queryParam);

		Long total = countQuery.getSingleResult();
		List<Notice> list = new ArrayList<>();
		if (total > 0) {
			TypedQuery<Notice> typedQuery = entityManager
					.createQuery(builder.toString() + " order by n.updateTime desc ", Notice.class);
			setParam(typedQuery, queryParam);
			typedQuery.setFirstResult(request.getPage() * request.getPageSize());// 数据起始位置index，从0开始
			typedQuery.setMaxResults(request.getPageSize());// 每页条数
			list = typedQuery.getResultList();

		}
		list.parallelStream().forEach(n -> {
			Notice notice = n;
			if (!CollectionUtils.isEmpty(notice.getReads())) {// 将该集合只设置自己的记录，前端根据此字段是否为空，进行判断是否已读，和阅读时间
				NoticeRead read = notice.getReads().stream().filter(r -> r.getNoticeReadId().getUserId().equals(userId))
						.findFirst().orElse(null);
				if (read == null) {
					notice.getReads().clear();
				}
			}
		});

		return new PageTableResponse(total, total, list);
	}

	private void setParam(TypedQuery<?> query, Map<String, Object> queryParam) {
		queryParam.forEach((k, v) -> {
			query.setParameter(k, v);
		});
	}

}
