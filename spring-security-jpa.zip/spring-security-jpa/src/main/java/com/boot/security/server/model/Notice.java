package com.boot.security.server.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@Table(name = "t_notice")
@DynamicInsert
@DynamicUpdate
public class Notice implements Serializable {

	private static final long serialVersionUID = -4401913568806243090L;

	@Id
	@GeneratedValue
	private Long id;
	private String title;
	private String content;
	private Integer status;
	@Column(updatable = false)
	private Date createTime = new Date();
	private Date updateTime = new Date();

	@OneToMany(cascade = CascadeType.REFRESH, mappedBy = "notice", fetch = FetchType.LAZY)
	private List<NoticeRead> reads;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public List<NoticeRead> getReads() {
		return reads;
	}

	public void setReads(List<NoticeRead> reads) {
		this.reads = reads;
	}

	public interface Status {
		int DRAFT = 0;
		int PUBLISH = 1;
	}

}
