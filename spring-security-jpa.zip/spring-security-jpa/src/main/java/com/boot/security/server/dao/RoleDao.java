package com.boot.security.server.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.boot.security.server.model.Role;

public interface RoleDao extends JpaRepository<Role, Long>, JpaSpecificationExecutor<Role> {

	Role findByName(String name);

	@Query("select r from Role r left join r.users u where u.id = :userId")
	List<Role> listByUserId(@Param("userId") Long userId);

}
