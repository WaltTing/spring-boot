package com.boot.security.server.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.security.server.annotation.LogAnnotation;
import com.boot.security.server.dao.NoticeDao;
import com.boot.security.server.dao.NoticeReadDao;
import com.boot.security.server.dto.NoticeVO;
import com.boot.security.server.model.Notice;
import com.boot.security.server.model.Notice.Status;
import com.boot.security.server.model.NoticeRead;
import com.boot.security.server.model.NoticeReadId;
import com.boot.security.server.model.SysUser;
import com.boot.security.server.page.table.PageTableHandler;
import com.boot.security.server.page.table.PageTableRequest;
import com.boot.security.server.page.table.PageTableResponse;
import com.boot.security.server.service.NoticeService;
import com.boot.security.server.utils.UserUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(tags = "公告")
@RestController
@RequestMapping("/notices")
public class NoticeController {

	@Autowired
	private NoticeDao noticeDao;
	@Autowired
	private NoticeReadDao noticeReadDao;

	@LogAnnotation
	@PostMapping
	@ApiOperation(value = "保存公告")
	@PreAuthorize("hasAuthority('notice:add')")
	public Notice saveNotice(@RequestBody Notice notice) {
		noticeDao.save(notice);

		return notice;
	}

	@GetMapping("/{id}")
	@ApiOperation(value = "根据id获取公告")
	@PreAuthorize("hasAuthority('notice:query')")
	public Notice get(@PathVariable Long id) {
		return noticeDao.findById(id).orElse(null);
	}

	@GetMapping(params = "id")
	public NoticeVO readNotice(Long id) {
		NoticeVO vo = new NoticeVO();

		Notice notice = noticeDao.findById(id).orElse(null);
		if (notice == null || notice.getStatus() == Status.DRAFT) {
			return vo;
		}
		vo.setNotice(notice);

		NoticeReadId readId = new NoticeReadId();
		readId.setUserId(UserUtil.getLoginUser().getId());
		readId.setNoticeId(id);

		NoticeRead noticeRead = noticeReadDao.findById(readId).orElse(null);
		if (noticeRead == null) {
			noticeRead = new NoticeRead();
			noticeRead.setNoticeReadId(readId);
			noticeRead.setCreateTime(new Date());

			noticeReadDao.save(noticeRead);
		}

		List<SysUser> users = noticeReadDao.listReadUsers(id);
		vo.setUsers(users);

		return vo;
	}

	@LogAnnotation
	@PutMapping
	@ApiOperation(value = "修改公告")
	@PreAuthorize("hasAuthority('notice:add')")
	public Notice updateNotice(@RequestBody Notice notice) {
		Notice no = noticeDao.findById(notice.getId()).orElse(null);
		if (no == null) {
			throw new IllegalArgumentException("公告不存在");
		}
		if (no.getStatus() == Status.PUBLISH) {
			throw new IllegalArgumentException("发布状态的不能修改");
		}
		notice.setUpdateTime(new Date());
		noticeDao.save(notice);

		return notice;
	}

	private Specification<Notice> specification(Map<String, Object> params) {
		Specification<Notice> spec = new Specification<Notice>() {

			private static final long serialVersionUID = 2359231687669663554L;

			@Override
			public Predicate toPredicate(Root<Notice> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<Predicate> predicate = new ArrayList<>();
				String title = MapUtils.getString(params, "title");
				if (StringUtils.isNoneBlank(title)) {
					predicate.add(cb.like(root.get("title"), "%" + title + "%"));
				}

				String beginTime = MapUtils.getString(params, "beginTime");
				if (StringUtils.isNoneBlank(beginTime)) {
					try {
						predicate.add(cb.greaterThan(root.get("updateTime").as(Date.class),
								DateUtils.parseDate(beginTime, "yyyy-MM-dd")));
					} catch (ParseException e) {
						e.printStackTrace();
					}
				}

				String endTime = MapUtils.getString(params, "endTime");
				if (StringUtils.isNoneBlank(endTime)) {
					try {
						predicate.add(cb.lessThan(root.get("updateTime").as(Date.class),
								DateUtils.parseDate(endTime + " 23:59:59", "yyyy-MM-dd HH:mm:ss")));
					} catch (ParseException e) {
						e.printStackTrace();
					}
				}

				Integer status = MapUtils.getInteger(params, "status");
				if (status != null) {
					predicate.add(cb.equal(root.get("status"), status));
				}

				return cb.and(predicate.toArray(new Predicate[predicate.size()]));
			}
		};

		return spec;
	}

	@GetMapping
	@ApiOperation(value = "公告管理列表")
	@PreAuthorize("hasAuthority('notice:query')")
	public PageTableResponse listNotice(PageTableRequest request) {
		return new PageTableHandler<Notice>().handle(noticeDao, specification(request.getParams()), request);
	}

	@Autowired
	private NoticeService noticeService;

	@LogAnnotation
	@DeleteMapping("/{id}")
	@ApiOperation(value = "删除公告")
	@PreAuthorize("hasAuthority('notice:del')")
	public void delete(@PathVariable Long id) {
		noticeDao.deleteById(id);
	}

	@ApiOperation(value = "未读公告数")
	@GetMapping("/count-unread")
	public Integer countUnread() {
		return noticeReadDao.countUnread(UserUtil.getLoginUser().getId());
	}

	@GetMapping("/published")
	@ApiOperation(value = "公告列表")
	public PageTableResponse listNoticeReadVO(PageTableRequest request) throws ParseException {
		Long userId = UserUtil.getLoginUser().getId();
		PageTableResponse response = noticeService.queryPubNotice(request, userId);
		return response;
	}

}
