package com.boot.security.server.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.security.server.dao.SysLogsDao;
import com.boot.security.server.model.SysLogs;
import com.boot.security.server.page.table.PageTableHandler;
import com.boot.security.server.page.table.PageTableRequest;
import com.boot.security.server.page.table.PageTableResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(tags = "日志")
@RestController
@RequestMapping("/logs")
public class SysLogsController {

	@Autowired
	private SysLogsDao sysLogsDao;

	private Specification<SysLogs> specification(Map<String, Object> params) {
		Specification<SysLogs> spec = new Specification<SysLogs>() {

			private static final long serialVersionUID = -4739529105077986393L;

			@Override
			public Predicate toPredicate(Root<SysLogs> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<Predicate> predicate = new ArrayList<>();
				Integer flag = MapUtils.getInteger(params, "flag");
				if (flag != null) {
					predicate.add(cb.equal(root.get("flag"), flag == 1));
				}

				String nickname = MapUtils.getString(params, "nickname");
				if (StringUtils.isNoneBlank(nickname)) {
					predicate.add(cb.like(root.join("user", JoinType.INNER).get("nickname"), "%" + nickname + "%"));
				}

				String beginTime = MapUtils.getString(params, "beginTime");
				if (StringUtils.isNoneBlank(beginTime)) {
					try {
						predicate.add(cb.greaterThan(root.get("createTime").as(Date.class),
								DateUtils.parseDate(beginTime, "yyyy-MM-dd")));
					} catch (ParseException e) {
						e.printStackTrace();
					}
				}

				String endTime = MapUtils.getString(params, "endTime");
				if (StringUtils.isNoneBlank(endTime)) {
					try {
						predicate.add(cb.lessThan(root.get("createTime").as(Date.class),
								DateUtils.parseDate(endTime + " 23:59:59", "yyyy-MM-dd HH:mm:ss")));
					} catch (ParseException e) {
						e.printStackTrace();
					}
				}

				return cb.and(predicate.toArray(new Predicate[predicate.size()]));
			}
		};

		return spec;
	}

	@GetMapping
	@PreAuthorize("hasAuthority('sys:log:query')")
	@ApiOperation(value = "日志列表")
	public PageTableResponse list(PageTableRequest request) {
		return new PageTableHandler<SysLogs>().handle(sysLogsDao, specification(request.getParams()), request);
	}

}
