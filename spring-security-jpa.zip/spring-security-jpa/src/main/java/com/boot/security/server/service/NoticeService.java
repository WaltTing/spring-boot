package com.boot.security.server.service;

import java.text.ParseException;

import com.boot.security.server.page.table.PageTableRequest;
import com.boot.security.server.page.table.PageTableResponse;

public interface NoticeService {

	PageTableResponse queryPubNotice(PageTableRequest request, Long userId) throws ParseException;
}
