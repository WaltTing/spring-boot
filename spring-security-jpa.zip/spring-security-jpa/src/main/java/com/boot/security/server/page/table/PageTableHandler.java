package com.boot.security.server.page.table;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * 分页查询处理器
 * 
 * @author 小威老师
 *
 */

public class PageTableHandler<T> {

	public PageTableResponse handle(JpaSpecificationExecutor<T> jpaSpecificationExecutor, Specification<T> spec,
			PageTableRequest tableRequest) {
		PageRequest pageRequest = null;
		if (tableRequest.getSort() == null) {
			pageRequest = PageRequest.of(tableRequest.getPage(), tableRequest.getPageSize());
		} else {
			pageRequest = PageRequest.of(tableRequest.getPage(), tableRequest.getPageSize(), tableRequest.getSort());
		}
		Page<T> page = jpaSpecificationExecutor.findAll(spec, pageRequest);

		PageTableResponse tableResponse = new PageTableResponse(page.getTotalElements(), page.getTotalElements(),
				page.getContent());

		return tableResponse;
	}
}