package com.boot.security.server.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "t_notice_read")
public class NoticeRead implements Serializable {

	private static final long serialVersionUID = 2982893055810775986L;

	@EmbeddedId
	private NoticeReadId noticeReadId;
	private Date createTime = new Date();

	@JsonIgnore
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
	@JoinColumn(name = "notice_id", insertable = false, updatable = false)
	private Notice notice;

	public NoticeReadId getNoticeReadId() {
		return noticeReadId;
	}

	public void setNoticeReadId(NoticeReadId noticeReadId) {
		this.noticeReadId = noticeReadId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Notice getNotice() {
		return notice;
	}

	public void setNotice(Notice notice) {
		this.notice = notice;
	}

}
