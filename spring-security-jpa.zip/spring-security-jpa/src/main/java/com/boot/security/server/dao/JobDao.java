package com.boot.security.server.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.boot.security.server.model.JobModel;

public interface JobDao extends JpaRepository<JobModel, Long>, JpaSpecificationExecutor<JobModel> {

	JobModel findByJobName(String jobName);
}
