package com.boot.security.server.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.boot.security.server.model.Dict;

public interface DictDao extends JpaRepository<Dict, Long>, JpaSpecificationExecutor<Dict> {

	Dict findByTypeAndK(String type, String k);

	List<Dict> findByType(String type);
}
