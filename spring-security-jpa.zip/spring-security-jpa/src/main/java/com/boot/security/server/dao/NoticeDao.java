package com.boot.security.server.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.boot.security.server.model.Notice;

public interface NoticeDao extends JpaRepository<Notice, Long>, JpaSpecificationExecutor<Notice> {

}
